package com.hashconcepts.buycart.data.remote.dto.response

/**
 * @created 28/06/2022 - 3:51 PM
 * @project BuyCart
 * @author  ifechukwu.udorji
 */
data class LoginResponse(
    val token: String,
)
