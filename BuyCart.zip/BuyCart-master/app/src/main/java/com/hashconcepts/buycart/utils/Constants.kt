package com.hashconcepts.buycart.utils

/**
 * @created 18/06/2022 - 1:49 PM
 * @project ComposePokedex
 * @author  ifechukwu.udorji
 */
object Constants {

    const val USER_IS_LOGGED_IN = "USER_IS_LOGGED_IN"
    const val IS_FIRST_APP_LAUNCH = "IS_FIRST_APP_LAUNCH"
}