package com.hashconcepts.buycart.presentation.screens.auth.login

/**
 * @created 01/07/2022 - 9:08 AM
 * @project BuyCart
 * @author  ifechukwu.udorji
 */
data class LoginScreenState(
    val isLoading: Boolean = false,
)
