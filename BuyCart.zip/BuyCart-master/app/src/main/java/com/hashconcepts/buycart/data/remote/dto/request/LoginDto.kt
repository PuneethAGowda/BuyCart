package com.hashconcepts.buycart.data.remote.dto.request

/**
 * @created 28/06/2022 - 3:51 PM
 * @project BuyCart
 * @author  ifechukwu.udorji
 */
data class LoginDto(
    val username: String,
    val password: String
)
